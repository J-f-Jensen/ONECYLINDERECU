//MCU definition file
#ifndef __MCUdefinitions_H
#define __MCUdefinitions_H

/*-- Includes ----------------------------------------------------------------*/
#include <generic.h>
#include "mc9s12t64.h" //MCU definitions not in generic.h


#endif /*__MCUdefinitions_H */